/*
 * gpio_controler.h
 *
 *  Created on: 2022年1月15日
 *      Author: guoqiang.xiong
 */

#ifndef APPLICATION_INC_GPIO_CONTROLER_H_
#define APPLICATION_INC_GPIO_CONTROLER_H_





void gpio_wr(int index,int wr_data);
int gpio_rd(int index);



#endif /* APPLICATION_INC_GPIO_CONTROLER_H_ */
