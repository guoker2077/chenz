#include <stdio.h>
#include "nuclei_sdk_hal.h"
#include "./inc/oled_display.h"
#include "../inc/dsi_configure.h"

int read_key = 0;

int main(void)
{  
	dsi_0_configure();
	lcd_screen_config();

    while(1)
    {
    	read_key = KEY_read();
     	LED_key(read_key);
//    	delay_1ms(1000);
//    	LED_Low();
//    	delay_1ms(1000);
    }

    return 0;
}


